# AFK Display
 Datapack that display players who have been afk for more than 5 minutes
